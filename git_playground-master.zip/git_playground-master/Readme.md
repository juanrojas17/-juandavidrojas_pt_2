# Espacio de trabajo
Los archivos contenidos en esta carpeta son una sencilla aplicacion web para permitirnos jugar haciendo los ejercicios de GIT contra un repositorio.

Los archivos originales los encontre en [https://github.com/lsnp/slideshow_](https://github.com/lsnp/slideshow_)
